$(function () {
    $('.js-basic-example, .js-exportable').DataTable({
        responsive: true
    });
});
