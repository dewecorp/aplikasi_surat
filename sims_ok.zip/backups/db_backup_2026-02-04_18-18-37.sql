SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS activity_log;

CREATE TABLE `activity_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `activity_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO activity_log VALUES("79","1","login","Login ke sistem","2026-02-04 06:28:11");
INSERT INTO activity_log VALUES("80","1","delete_backup","Menghapus file backup (db_backup_2026-01-24_09-27-33.sql)","2026-02-04 08:28:46");
INSERT INTO activity_log VALUES("81","1","logout","Logout dari sistem","2026-02-04 08:30:11");
INSERT INTO activity_log VALUES("82","1","login","Login ke sistem","2026-02-04 08:33:10");
INSERT INTO activity_log VALUES("83","1","update","Mengubah data guru: Ah. Mustaqim Isom, A.Ma.","2026-02-04 08:56:05");
INSERT INTO activity_log VALUES("84","1","update","Mengubah surat keluar no: 006/MI.SF/I/2026","2026-02-04 08:56:36");
INSERT INTO activity_log VALUES("85","1","update","Mengubah data guru: Abdul Ghofur, S.Pd.I","2026-02-04 09:03:47");
INSERT INTO activity_log VALUES("86","1","update","Mengubah data guru: Alfina Martha Sintya, S.Pd.","2026-02-04 09:03:59");
INSERT INTO activity_log VALUES("87","1","logout","Logout dari sistem","2026-02-04 15:36:57");
INSERT INTO activity_log VALUES("88","1","login","Login ke sistem","2026-02-04 15:37:07");
INSERT INTO activity_log VALUES("89","1","logout","Logout dari sistem","2026-02-04 17:41:00");
INSERT INTO activity_log VALUES("90","1","login","Login ke sistem","2026-02-04 17:41:08");
INSERT INTO activity_log VALUES("91","1","update","Mengubah data guru: Abdul Ghofur, S.Pd.I","2026-02-04 17:43:58");
INSERT INTO activity_log VALUES("92","1","logout","Logout dari sistem","2026-02-04 17:44:16");
INSERT INTO activity_log VALUES("93","1","login","Login ke sistem","2026-02-04 17:53:25");



DROP TABLE IF EXISTS backup;

CREATE TABLE `backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO backup VALUES("8","db_backup_2026-01-24_19-07-06.sql","17.44 KB","2026-01-24 19:07:06");



DROP TABLE IF EXISTS guru;

CREATE TABLE `guru` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nuptk` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jk` enum('L','P') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat_lahir` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `status` enum('Guru Kelas','Guru Mapel') COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO guru VALUES("7","2444764667200003","Abdul Ghofur, S.Pd.I","L","Jepara","1986-12-11","Guru Kelas");
INSERT INTO guru VALUES("8","7841746648200002","Ah. Mustaqim Isom, A.Ma.","L","Jepara",NULL,"Guru Mapel");
INSERT INTO guru VALUES("9","3320011122345","Alfina Martha Sintya, S.Pd.","P","Jepara",NULL,"Guru Mapel");
INSERT INTO guru VALUES("10","9547746647110022","Ali Yasin, S.Pd.I","L","Jepara",NULL,"Guru Kelas");
INSERT INTO guru VALUES("11","4444747649200002","Hamidah, A.Ma.","P","Jepara",NULL,"Guru Mapel");
INSERT INTO guru VALUES("12","2640755657300002","Indasah, A.Ma.","P","Jepara",NULL,"Guru Mapel");
INSERT INTO guru VALUES("13","ID20318581190001","Khoiruddin, S.Pd.","L","Jepara",NULL,"Guru Mapel");
INSERT INTO guru VALUES("14","8552750652200002","Muhamad Junaedi","L","Jepara",NULL,"Guru Mapel");
INSERT INTO guru VALUES("15","6956748651300002","Musri`ah, S.Pd.I","P","Jepara",NULL,"Guru Mapel");
INSERT INTO guru VALUES("16","6556755656300002","Nanik Purwati, S.Pd.I","P","Jepara",NULL,"Guru Kelas");
INSERT INTO guru VALUES("17","7357760661300003","Nur Hidah, S.Pd.I.","P","Jepara",NULL,"Guru Kelas");
INSERT INTO guru VALUES("18","5436757658200002","Nur Huda, S.Pd.I.","L","Jepara","1979-04-01","Guru Kelas");
INSERT INTO guru VALUES("19","8041756657300003","Zama`ah, S.Pd.I.","P","Jepara",NULL,"Guru Kelas");



DROP TABLE IF EXISTS pengaturan;

CREATE TABLE `pengaturan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_yayasan` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_madrasah` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kepala_madrasah` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ttd` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stempel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_aplikasi` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_login` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO pengaturan VALUES("1","YAYASAN SULTAN FATTAH JEPARA","MI SULTAN FATTAH SUKOSONO","Jalan Kauman RT. 10 RW. 03 Sukosono Kedung Jepara 59463","misultanfattah@gmail.com","https://misultanfattah.sch.id/","Musriah, S.Pd.I.","6983214047aca_logo.png","1769172028_ttd_tanda tangan kepala.png","1769172028_stempel_stempel.png","SISTEM MANAJEMEN SURAT","698322573cf9d_bg.jpg");



DROP TABLE IF EXISTS surat_keluar;

CREATE TABLE `surat_keluar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tgl_surat` date NOT NULL,
  `no_surat` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_surat` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `perihal` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `penerima` text COLLATE utf8mb4_unicode_ci,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `acara_hari_tanggal` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acara_waktu` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `acara_tempat` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keperluan` text COLLATE utf8mb4_unicode_ci,
  `keterangan` text COLLATE utf8mb4_unicode_ci,
  `pembuka_surat` text COLLATE utf8mb4_unicode_ci,
  `isi_surat` text COLLATE utf8mb4_unicode_ci,
  `penutup_surat` text COLLATE utf8mb4_unicode_ci,
  `nis_siswa` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tempat_lahir_siswa` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl_lahir_siswa` date DEFAULT NULL,
  `jenis_kelamin_siswa` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kelas_siswa` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nama_wali` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pekerjaan_wali` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alamat_wali` text COLLATE utf8mb4_unicode_ci,
  `tujuan_pindah` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO surat_keluar VALUES("2","2026-01-24","002/MI.SF/I/2026","Undangan","Undangan Rapat Perpisahan","Dewan Guru",NULL,"2026-01-24 05:04:37","2026-01-27","08:00","Aula Madrasah","Rapat Persiapan Perpisahan","Harap tidak absen",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO surat_keluar VALUES("3","2026-01-24","003/MI.SF/I/2026","Pemberitahuan","Pemberitahuan Biaya Ujian 2026","Wali Murid Kelas 6",NULL,"2026-01-24 08:04:48",NULL,NULL,NULL,NULL,NULL,"Assalamu\'alaikum Wr. Wb.

Sesuai dengan hasil rapat bersama antara Wali Murid Kelas VI dan Kepala  Madrasah pada Hari Ahad, Tanggal 26 Januari 2025 di MI. Sultan Fattah Sukosono Kedung Jepara, Menghasilkan keputusan sebagai berikut :","<ol>
	<li>Rincian Biaya Ujian:</li>
</ol>

<table align=\"center\" border=\"1\" bordercolor=\"#ccc\" cellpadding=\"5\" cellspacing=\"0\" style=\"border-collapse:collapse\">
	<tbody>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>&nbsp;NO</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;URAIAN</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;NOMINAL</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>1</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;STOR UJIAN + BUKU</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;Rp. 190,000</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>2</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;FOTO DAN LAMINATING</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;Rp. 45,000</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>3</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;Pencetakan Ijasah</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;Rp. 20,000</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>4</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;KOREKTOR</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;Rp. 30,000</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>5</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;PELAKSANAAN UJIAN</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;Rp. 100,000</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>6</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;ADMINISTRASI</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;Rp. 20,000</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>7</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;LES</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;Rp. 80,000</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>8</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;PERPISAHAN</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;Rp. 180,000</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:8px; width:47px\">
			<p>9</p>
			</td>
			<td style=\"height:8px; width:315px\">
			<p>&nbsp;KENANG-KENANGAN</p>
			</td>
			<td style=\"height:8px; width:181px\">
			<p>&nbsp;Rp. 150,000</p>
			</td>
		</tr>
		<tr>
			<td style=\"height:33px; width:47px\">
			<p>&nbsp;</p>
			</td>
			<td style=\"height:33px; width:315px\">
			<p>&nbsp;Jumlah</p>
			</td>
			<td style=\"height:33px; width:181px\">
			<p>&nbsp;<strong>Rp.</strong><strong> 815.000</strong></p>
			</td>
		</tr>
	</tbody>
</table>

<p>&nbsp;</p>

<p>2. Biaya Ujian Madrasah Bisa Diangsur mulai 10 febuari 2025 sd. Tanggal 20 April&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;2025</p>
","Demikian pemberitahuan ini kami sampaikan. Atas perhatian dan kerjasamanya kami ucapkan terima kasih.

Wassalamu\'alaikum Wr. Wb.",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO surat_keluar VALUES("6","2026-01-24","004/MI.SF/I/2026","Tugas","Kegiatan KKG KKMI Kedung","Ali Yasin, S.Pd.I; Khoiruddin, S.Pd.; Nanik Purwati, S.Pd.I",NULL,"2026-01-24 11:46:25","2026-01-25 s.d 2026-01-26","08.00 - selesai","MI Salafiyah Wanusobo",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO surat_keluar VALUES("7","2026-01-24","005/MI.SF/I/2026","Keterangan Pindah","Surat Keterangan Pindah","MUHAMMAD AINUN NAJIB",NULL,"2026-01-24 15:01:08",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL," 3189060879","Jepara","2018-06-17","Laki-Laki","II","ABDUL JALIL"," Wiraswasta","LANGON RT 14/06 TAHUNAN Jepara","SDN I LANGON");
INSERT INTO surat_keluar VALUES("8","2026-01-25","006/MI.SF/I/2026","Undangan","Undangan Rapat TKA","Panitia TKA",NULL,"2026-01-25 19:24:10","2026-01-29","20:00","Kantor MI","Rapat Panitia TKA","Mohon hadir tepat waktu",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);



DROP TABLE IF EXISTS surat_masuk;

CREATE TABLE `surat_masuk` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tgl_terima` date NOT NULL,
  `no_surat` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_surat` date NOT NULL,
  `perihal` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pengirim` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO surat_masuk VALUES("1","2026-01-15","020/YYS.SF/I/2026","2026-01-23","Undangan Buka Bersama","Pengurus Yayasan","1769168023_Rekap_Absensi_Guru_-_Semester_2_(2025_2026).pdf","2026-01-23 18:33:46");
INSERT INTO surat_masuk VALUES("2","2026-01-23","020/YYS.SF/I/2026","2026-01-23","Rapat Pengurus","Pengurus Yayasan","1769169348_WhatsApp Image 2026-01-12 at 11.12.51.jpeg","2026-01-23 18:55:48");



DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'default.jpg',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO users VALUES("1","Admin ","Admin","$2y$10$qWA7mN7CKrMRFl16gQ4kbu6DQkpnxMzelxrJaEnzkFRi1ZrRdyVEi","admin","default.jpg");
INSERT INTO users VALUES("2","Khoiruddin, S.Pd.","TU","$2y$10$j47mH7L2B0grfVPw21wyEea8LEdQMk/X53hCj2CgL2vmtuTvxgRna","","default.jpg");



SET FOREIGN_KEY_CHECKS=1;