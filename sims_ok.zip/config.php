<?php
$request_host = isset($_SERVER['HTTP_HOST']) ? strtolower((string)$_SERVER['HTTP_HOST']) : '';
$is_local = $request_host === ''
    || strpos($request_host, 'localhost') !== false
    || strpos($request_host, '127.0.0.1') !== false
    || strpos($request_host, '.test') !== false
    || strpos($request_host, '.local') !== false;

$host = getenv('DB_HOST') ?: 'localhost';
$user = getenv('DB_USER') ?: ($is_local ? 'root' : 'kvzveyrg_sims');
$pass = getenv('DB_PASS') ?: ($is_local ? '' : 'sultanfattah25');
$db   = getenv('DB_NAME') ?: ($is_local ? 'sims' : 'kvzveyrg_sims');

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set timezone
date_default_timezone_set('Asia/Jakarta');
// Ensure MySQL session uses Asia/Jakarta (WIB, UTC+07:00)
if ($conn) {
    @mysqli_query($conn, "SET time_zone = '+07:00'");
}

// Base URL
$protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') ? 'https' : 'http';
$host_url = isset($_SERVER['HTTP_HOST']) ? (string)$_SERVER['HTTP_HOST'] : '';
$app_url = getenv('APP_URL') ?: '';
if ($app_url && filter_var($app_url, FILTER_VALIDATE_URL)) {
    $base_url = rtrim($app_url, '/') . '/';
} elseif ($host_url !== '') {
    $script_dir = isset($_SERVER['SCRIPT_NAME']) ? str_replace('\\', '/', dirname((string)$_SERVER['SCRIPT_NAME'])) : '';
    $script_dir = trim($script_dir, '/');
    $base_path = ($script_dir !== '' && $script_dir !== '.') ? '/' . $script_dir : '';
    $base_url = $protocol . '://' . $host_url . $base_path . '/';
} else {
    $base_url = $protocol . '://localhost/';
}

function getRomawi($n){
    $hasil = "";
    $iromawi = array("","I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII");
    if(array_key_exists($n,$iromawi)){
        $hasil = $iromawi[$n];
    }
    return $hasil;
}

function to_romawi($number) {
    $map = array('M' => 1000, 'CM' => 900, 'D' => 500, 'CD' => 400, 'C' => 100, 'XC' => 90, 'L' => 50, 'XL' => 40, 'X' => 10, 'IX' => 9, 'V' => 5, 'IV' => 4, 'I' => 1);
    $returnValue = '';
    while ($number > 0) {
        foreach ($map as $roman => $int) {
            if($number >= $int) {
                $number -= $int;
                $returnValue .= $roman;
                break;
            }
        }
    }
    return $returnValue;
}

// Function to properly format names with academic titles
function properCaseName($name) {
    // Convert to lowercase first
    $name = strtolower($name);
    
    // Capitalize first letter of each word
    $name = ucwords($name);
    
    // Fix MI (Madrasah Ibtidaiyah) to uppercase - replace all variations
    $name = str_ireplace('mi', 'MI', $name);
    $name = str_ireplace('Mi', 'MI', $name);
    
    // Fix common academic titles capitalization - handle both with and without spaces
    $replacements = array(
        'S. Pd. I' => 'S.Pd.I',
        'S. Pd' => 'S.Pd',
        'S. Ag' => 'S.Ag',
        'S. E' => 'S.E',
        'S. Kom' => 'S.Kom',
        'S. T' => 'S.T',
        'S. Sos' => 'S.Sos',
        'S. Psi' => 'S.Psi',
        'M. Pd' => 'M.Pd',
        'M. Pd. I' => 'M.Pd.I',
        'M. Ag' => 'M.Ag',
        'M. E' => 'M.E',
        'M. Kom' => 'M.Kom',
        'M. T' => 'M.T',
        'M. Si' => 'M.Si',
        'Dr.' => 'Dr.',
        'Prof.' => 'Prof.',
        'Hj.' => 'Hj.',
        'H.' => 'H.',
        // Also fix if already without spaces but wrong case
        'S.pd.i' => 'S.Pd.I',
        'S.pd' => 'S.Pd',
        'S.ag' => 'S.Ag',
        'S.e' => 'S.E',
        'S.kom' => 'S.Kom',
        'S.t' => 'S.T',
        'S.sos' => 'S.Sos',
        'S.psi' => 'S.Psi',
        'M.pd' => 'M.Pd',
        'M.pd.i' => 'M.Pd.I',
        'M.ag' => 'M.Ag',
        'M.e' => 'M.E',
        'M.kom' => 'M.Kom',
        'M.t' => 'M.T',
        'M.si' => 'M.Si',
    );
    
    foreach ($replacements as $key => $value) {
        $name = str_ireplace($key, $value, $name);
    }
    
    return $name;
}

function tgl_indo($tanggal){
	$bulan = array (
		1 =>   'Januari',
		'Februari',
		'Maret',
		'April',
		'Mei',
		'Juni',
		'Juli',
		'Agustus',
		'September',
		'Oktober',
		'November',
		'Desember'
	);
	$pecahkan = explode('-', $tanggal);
	
	// variabel pecahkan 0 = tanggal
	// variabel pecahkan 1 = bulan
	// variabel pecahkan 2 = tahun
 
	return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}

function hari_indo($tanggal){
    $hari = array ( 1 =>    'Senin',
        'Selasa',
        'Rabu',
        'Kamis',
        'Jumat',
        'Sabtu',
        'Minggu'
    );
    $num = date('N', strtotime($tanggal));
    return $hari[$num];
}

function getInitials($name) {
    $words = explode(" ", $name);
    $initials = "";
    foreach ($words as $w) {
        if (!empty($w)) {
            $initials .= $w[0];
        }
    }
    return strtoupper(substr($initials, 0, 2));
}

function getAvatarColor($name) {
    $colors = ['#F44336', '#E91E63', '#9C27B0', '#673AB7', '#3F51B5', '#2196F3', '#03A9F4', '#00BCD4', '#009688', '#4CAF50', '#8BC34A', '#CDDC39', '#FFC107', '#FF9800', '#FF5722', '#795548', '#9E9E9E', '#607D8B'];
    $index = abs(crc32($name)) % count($colors);
    return $colors[$index];
}

function log_activity($user_id, $type, $description) {
    global $conn;
    static $has_timestamp_column = null;
    $user_id = mysqli_real_escape_string($conn, $user_id);
    $type = mysqli_real_escape_string($conn, $type);
    $description = mysqli_real_escape_string($conn, $description);

    // Cek apakah user_id masih ada di tabel users
    $check_user = mysqli_query($conn, "SELECT id FROM users WHERE id='$user_id'");
    if (mysqli_num_rows($check_user) > 0) {
        if ($has_timestamp_column === null) {
            $check_col = @mysqli_query($conn, "SHOW COLUMNS FROM activity_log LIKE 'timestamp'");
            $has_timestamp_column = $check_col && mysqli_num_rows($check_col) > 0;
        }
        if ($has_timestamp_column) {
            $ts = mysqli_real_escape_string($conn, date('Y-m-d H:i:s'));
            $query = "INSERT INTO activity_log (user_id, activity_type, description, timestamp) VALUES ('$user_id', '$type', '$description', '$ts')";
            @mysqli_query($conn, $query);
        } else {
            $query = "INSERT INTO activity_log (user_id, activity_type, description) VALUES ('$user_id', '$type', '$description')";
            @mysqli_query($conn, $query);
        }
    }
}

function time_ago($timestamp) {
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    $minutes      = round($seconds / 60);
    $hours        = round($seconds / 3600);
    $days         = round($seconds / 86400);
    $weeks        = round($seconds / 604800);
    $months       = round($seconds / 2629440);
    $years        = round($seconds / 31553280);

    if ($seconds <= 60) {
        return "Baru saja";
    } else if ($minutes <= 60) {
        if ($minutes == 1) {
            return "satu menit yang lalu";
        } else {
            return "$minutes menit yang lalu";
        }
    } else if ($hours <= 24) {
        if ($hours == 1) {
            return "satu jam yang lalu";
        } else {
            return "$hours jam yang lalu";
        }
    } else if ($days <= 7) {
        if ($days == 1) {
            return "kemarin";
        } else {
            return "$days hari yang lalu";
        }
    } else if ($weeks <= 4.3) {
        if ($weeks == 1) {
            return "satu minggu yang lalu";
        } else {
            return "$weeks minggu yang lalu";
        }
    } else if ($months <= 12) {
        if ($months == 1) {
            return "satu bulan yang lalu";
        } else {
            return "$months bulan yang lalu";
        }
    } else {
        if ($years == 1) {
            return "satu tahun yang lalu";
        } else {
            return "$years tahun yang lalu";
        }
    }
}

// CSRF Protection Functions
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    if (isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token)) {
        return true;
    }
    return false;
}

// Auto delete logs older than 24 hours
mysqli_query($conn, "DELETE FROM activity_log WHERE timestamp < NOW() - INTERVAL 1 DAY");
