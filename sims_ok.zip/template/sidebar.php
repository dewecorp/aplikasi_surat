<?php
// Sidebar kini dirender di template/header.php menggunakan SB Admin 2.
// File ini dibiarkan kosong agar kompatibel dengan include yang ada.
?>
